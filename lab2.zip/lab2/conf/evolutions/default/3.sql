# --- Sample dataset

# --- !Ups
insert into customer (id,name, email) values (1, 'peter',  'petermarting@gmail.com');
insert into customer (id,name, email) values (2, 'Jimmy',  'jimhen@gmail.com');
insert into customer (id,name, email) values (3, 'Barry', 'breilly@gmail.com');